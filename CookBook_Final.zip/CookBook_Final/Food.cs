﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CookBook_Final
{
    internal class Food
    {
        private string _coverImage;
        private string _category;
        private string _description;
        private string _foodtitle;
        private string _Document;
        public Food(string coverImage, string foodtitle, string description, string category, string document)
        {
            _coverImage = coverImage;
            _foodtitle = foodtitle;
            _description = description;
            _category = category;              
            _Document = document;
        }
        public string CoverImage => _coverImage;
        public string Category => _category;
        public string Description => _description;
        public string Foodtitle => _foodtitle;
        public string Document => _Document;
    }
}
