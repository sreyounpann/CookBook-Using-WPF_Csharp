﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CookBook_Final
{
    internal sealed class DataContext
    {
        private readonly IEnumerable<Food> cuisine;

        public DataContext()
        {
            cuisine = new[]
            {
                   new Food("/Image/img5.jpg","LOK LAK SACH KO","LOK LAK is mix with  Beef and Rice","Cuisine", "\\Text\\lok lak.txt"),

                   new Food("/Image/img2.jpg","BAN CHEAV" , "Banh Cheav is very popolar for Cambodian", "Cuisine","\\Text\\Banh Chheav.txt"),

                   new Food ("/Image/img6.jpg" ,"NOm Banh JOK",  "Nom Bang Jok is a khmer Cuisine","Cuisine", "\\Text\\Nom Banh Jok.txt"),

                   new Food( "/Image/img7.png" ,"AMOK FISH", "AMOK FISH is really yummy", "Cuisine","\\Text\\Amok.txt"),

                   new Food("/Image/img8.jpg", "SAMLOR KORKO", "Samlor Korko is really tasty","Cuisine","\\Text\\Kako.txt"),
            };

        }
        public IEnumerable<Food> Cuisine => cuisine;
    }
}
